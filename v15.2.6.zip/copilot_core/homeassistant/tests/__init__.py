"""HomeAssistant Integration Tests."""
