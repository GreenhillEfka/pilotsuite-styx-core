"""Energy Forecast API Endpoints — v12.6.0.

REST API für Energie-Prognosen:
- Verbrauchsprognose (24h/7d)
- PV-Ertragsprognose
- Load Shifting Empfehlungen
- Kostenoptimierung

GET /api/v1/energy/forecast/consumption
GET /api/v1/energy/forecast/pv
GET /api/v1/energy/forecast/combined
GET /api/v1/energy/load-shifting/recommendations
GET /api/v1/energy/load-shifting/windows
POST /api/v1/energy/load-shifting/devices
"""

from __future__ import annotations

import logging
from dataclasses import asdict
from datetime import datetime
from typing import Optional

from flask import Blueprint, jsonify, request, current_app

from copilot_core.api.security import require_token
from copilot_core.energy.forecast import EnergyForecastEngine
from copilot_core.energy.pv_prediction import PVPredictionEngine
from copilot_core.energy.load_shifting import LoadShiftingEngine, ShiftableDevice

_LOGGER = logging.getLogger(__name__)

energy_forecast_bp = Blueprint("energy_forecast", __name__, url_prefix="/api/v1/energy")


def _get_weather_service():
    """Hole Weather Service aus App Config."""
    try:
        services = current_app.config.get("COPILOT_SERVICES", {})
        return services.get("weather_service")
    except Exception:
        return None


def _get_energy_service():
    """Hole Energy Service aus App Config."""
    try:
        services = current_app.config.get("COPILOT_SERVICES", {})
        return services.get("energy_service")
    except Exception:
        return None


def _fetch_weather_forecast(hours: int = 48) -> list[dict]:
    """Hole Wetterdaten von Weather Service."""
    weather_service = _get_weather_service()
    if not weather_service:
        return []
    
    try:
        # Annahme: Weather Service hat get_forecast Methode
        forecast = weather_service.get_forecast(hours=hours)
        return forecast if isinstance(forecast, list) else []
    except Exception as e:
        _LOGGER.warning("Weather forecast fetch error: %s", e)
        return []


def _fetch_price_forecast(hours: int = 48) -> list[dict]:
    """Hole Strompreis-Prognose."""
    energy_service = _get_energy_service()
    if not energy_service:
        return []
    
    try:
        # Annahme: Energy Service hat Preis-Daten
        prices = energy_service.get_price_forecast(hours=hours)
        return prices if isinstance(prices, list) else []
    except Exception as e:
        _LOGGER.warning("Price forecast fetch error: %s", e)
        return []


@energy_forecast_bp.route("/forecast/consumption", methods=["GET"])
@require_token
def get_consumption_forecast():
    """Hole Verbrauchsprognose.
    
    Query Params:
    - hours: Prognosehorizont (default 48, max 168)
    - include_weather: Wettereinfluss berücksichtigen (default true)
    
    Returns:
    {
        "ok": true,
        "generated_at": "...",
        "forecast_horizon_hours": 48,
        "summary": {...},
        "hourly_forecast": [...],
        "daily_forecast": [...]
    }
    """
    try:
        hours = min(int(request.args.get("hours", 48)), 168)
        include_weather = request.args.get("include_weather", "true").lower() == "true"
        
        # Engine initialisieren
        engine = EnergyForecastEngine()
        
        # Standort von Energy Service oder Config
        energy_service = _get_energy_service()
        if energy_service:
            try:
                location = energy_service.get_location()
                if location:
                    engine.update_location(location.get("lat", 51.0), location.get("lon", 10.0))
            except Exception:
                pass
        
        # Wetterdaten
        weather_data = []
        if include_weather:
            weather_raw = _fetch_weather_forecast(hours)
            weather_data = [
                {
                    "temperature_c": w.get("temperature_c"),
                    "cloud_cover_pct": w.get("cloud_cover_pct", 50),
                }
                for w in weather_raw
            ] if weather_raw else []
        
        # Generiere Prognose
        result = engine.get_forecast_as_dict(hours=hours, weather_data=weather_data)
        
        return jsonify({
            "ok": True,
            **result,
        })
    
    except Exception as e:
        _LOGGER.error("Consumption forecast error: %s", e)
        return jsonify({
            "ok": False,
            "error": str(e),
        }), 500


@energy_forecast_bp.route("/forecast/pv", methods=["GET"])
@require_token
def get_pv_forecast():
    """Hole PV-Ertragsprognose.
    
    Query Params:
    - hours: Prognosehorizont (default 48)
    - peak_kw: PV-Anlagenleistung (optional, sonst Config)
    - azimuth: Panel-Ausrichtung (optional)
    - tilt: Panel-Neigung (optional)
    
    Returns:
    {
        "ok": true,
        "pv_system": {...},
        "location": {...},
        "summary": {...},
        "hourly_forecast": [...],
        "daily_forecast": [...]
    }
    """
    try:
        hours = min(int(request.args.get("hours", 48)), 168)
        peak_kw = float(request.args.get("peak_kw", 10.0))
        azimuth = float(request.args.get("azimuth", 180.0))
        tilt = float(request.args.get("tilt", 30.0))
        
        # Engine initialisieren
        engine = PVPredictionEngine(
            pv_peak_kw=peak_kw,
            panel_azimuth=azimuth,
            panel_tilt=tilt,
        )
        
        # Standort
        energy_service = _get_energy_service()
        if energy_service:
            try:
                location = energy_service.get_location()
                if location:
                    engine.update_location(location.get("lat", 51.0), location.get("lon", 10.0))
            except Exception:
                pass
        
        # Wetterdaten
        weather_raw = _fetch_weather_forecast(hours)
        if weather_raw:
            weather_data = [
                {
                    "timestamp": w.get("timestamp"),
                    "temperature_c": w.get("temperature_c"),
                    "cloud_cover_pct": w.get("cloud_cover_pct", 50),
                    "precipitation_mm": w.get("precipitation_mm", 0),
                    "weather_code": w.get("weather_code", 0),
                }
                for w in weather_raw
            ]
            engine.set_weather_data(weather_data)
        
        # Generiere Prognose
        result = engine.get_pv_forecast_as_dict(hours=hours)
        
        return jsonify({
            "ok": True,
            **result,
        })
    
    except Exception as e:
        _LOGGER.error("PV forecast error: %s", e)
        return jsonify({
            "ok": False,
            "error": str(e),
        }), 500


@energy_forecast_bp.route("/forecast/combined", methods=["GET"])
@require_token
def get_combined_forecast():
    """Hole kombinierte Energie-Prognose (Verbrauch + PV + Preise).
    
    Query Params:
    - hours: Prognosehorizont (default 48)
    - include_load_shifting: Load Shifting Empfehlungen (default true)
    
    Returns:
    {
        "ok": true,
        "consumption": {...},
        "pv": {...},
        "prices": {...},
        "balance": [...],  # Stunde für Stunde
        "recommendations": [...]
    }
    """
    try:
        hours = min(int(request.args.get("hours", 48)), 168)
        include_shifting = request.args.get("include_load_shifting", "true").lower() == "true"
        
        # Hole Einzelprognosen
        consumption_engine = EnergyForecastEngine()
        pv_engine = PVPredictionEngine()
        
        # Wetterdaten
        weather_raw = _fetch_weather_forecast(hours)
        weather_data = [
            {
                "temperature_c": w.get("temperature_c"),
                "cloud_cover_pct": w.get("cloud_cover_pct", 50),
            }
            for w in weather_raw
        ] if weather_raw else []
        
        # Verbrauchsprognose
        consumption_forecast = consumption_engine.generate_hourly_forecast(
            hours=hours,
            weather_data=weather_data,
        )
        
        # PV-Prognose
        pv_weather_data = []
        if weather_raw:
            pv_weather_data = [
                {
                    "timestamp": w.get("timestamp"),
                    "temperature_c": w.get("temperature_c"),
                    "cloud_cover_pct": w.get("cloud_cover_pct", 50),
                    "precipitation_mm": w.get("precipitation_mm", 0),
                    "weather_code": w.get("weather_code", 0),
                }
                for w in weather_raw
            ]
            pv_engine.set_weather_data(pv_weather_data)
        
        pv_forecast = pv_engine.generate_hourly_forecast(hours=hours)
        
        # Preisprognose
        price_forecast = _fetch_price_forecast(hours)
        
        # Balance berechnen (PV - Verbrauch)
        balance = []
        for i in range(hours):
            consumption = consumption_forecast[i].predicted_consumption_kw if i < len(consumption_forecast) else 0
            pv = pv_forecast[i].pv_power_kw if i < len(pv_forecast) else 0
            price = price_forecast[i].get("price_ct_kwh", 30.0) if i < len(price_forecast) else 30.0
            
            balance.append({
                "hour": i,
                "timestamp": consumption_forecast[i].timestamp if i < len(consumption_forecast) else "",
                "consumption_kw": round(consumption, 3),
                "pv_kw": round(pv, 3),
                "balance_kw": round(pv - consumption, 3),  # Positiv = Überschuss
                "price_ct_kwh": round(price, 2),
                "self_sufficiency_pct": round(min(100, pv / max(0.1, consumption) * 100), 1),
            })
        
        # Load Shifting Empfehlungen
        recommendations = []
        if include_shifting:
            shifting_engine = LoadShiftingEngine(
                pv_forecast=[asdict(p) for p in pv_forecast],
                price_forecast=price_forecast,
                consumption_forecast=[asdict(c) for c in consumption_forecast],
            )
            
            # Standard-Geräte hinzufügen
            shifting_engine.add_device_from_profile("washer_1", "washer", "Waschmaschine")
            shifting_engine.add_device_from_profile("dryer_1", "dryer", "Wäschetrockner")
            shifting_engine.add_device_from_profile("dishwasher_1", "dishwasher", "Geschirrspüler")
            shifting_engine.add_device_from_profile("ev_1", "ev_charger", "EV-Ladestation")
            
            rec_result = shifting_engine.get_recommendations_as_dict()
            recommendations = rec_result.get("recommendations", [])
        
        return jsonify({
            "ok": True,
            "generated_at": datetime.now().isoformat(),
            "forecast_horizon_hours": hours,
            "consumption_summary": asdict(consumption_engine.generate_summary(consumption_forecast)),
            "pv_summary": asdict(pv_engine.generate_summary(pv_forecast)),
            "balance": balance,
            "recommendations": recommendations,
        })
    
    except Exception as e:
        _LOGGER.error("Combined forecast error: %s", e)
        return jsonify({
            "ok": False,
            "error": str(e),
        }), 500


@energy_forecast_bp.route("/load-shifting/recommendations", methods=["GET"])
@require_token
def get_load_shifting_recommendations():
    """Hole Load Shifting Empfehlungen.
    
    Query Params:
    - hours: Betrachtungshorizont (default 24)
    
    Returns:
    {
        "ok": true,
        "summary": {...},
        "recommendations": [...],
        "optimization_windows": [...]
    }
    """
    try:
        hours = min(int(request.args.get("hours", 24)), 48)
        
        # Daten holen
        pv_raw = _fetch_weather_forecast(hours)
        pv_forecast = []
        if pv_raw:
            # Vereinfachte PV-Schätzung aus Bewölkung
            for i, w in enumerate(pv_raw):
                cloud = w.get("cloud_cover_pct", 50)
                pv_kw = max(0, 5.0 * (1 - cloud / 100))  # 5kW Peak Annahme
                pv_forecast.append({"pv_power_kw": pv_kw})
        
        price_forecast = _fetch_price_forecast(hours)
        consumption_forecast = []  # Könnte von Energy Service kommen
        
        # Engine
        engine = LoadShiftingEngine(
            pv_forecast=pv_forecast,
            price_forecast=price_forecast,
            consumption_forecast=consumption_forecast,
        )
        
        # Standard-Geräte
        engine.add_device_from_profile("washer_1", "washer", "Waschmaschine")
        engine.add_device_from_profile("dryer_1", "dryer", "Wäschetrockner")
        engine.add_device_from_profile("dishwasher_1", "dishwasher", "Geschirrspüler")
        engine.add_device_from_profile("ev_1", "ev_charger", "EV-Ladestation", power_kw=11.0, energy_kwh=40.0)
        
        result = engine.get_recommendations_as_dict()
        
        return jsonify({
            "ok": True,
            **result,
        })
    
    except Exception as e:
        _LOGGER.error("Load shifting recommendations error: %s", e)
        return jsonify({
            "ok": False,
            "error": str(e),
        }), 500


@energy_forecast_bp.route("/load-shifting/windows", methods=["GET"])
@require_token
def get_optimization_windows():
    """Hole optimale Zeitfenster für Verbrauch.
    
    Query Params:
    - hours: Horizont (default 24)
    
    Returns:
    {
        "ok": true,
        "windows": [
            {
                "start": "...",
                "end": "...",
                "avg_price_ct_kwh": ...,
                "avg_pv_power_kw": ...,
                "recommendation": "..."
            },
            ...
        ]
    }
    """
    try:
        hours = min(int(request.args.get("hours", 24)), 48)
        
        # Engine mit minimalen Daten
        engine = LoadShiftingEngine()
        
        # Wetter für PV
        weather_raw = _fetch_weather_forecast(hours)
        if weather_raw:
            pv_forecast = [
                {"pv_power_kw": max(0, 5.0 * (1 - w.get("cloud_cover_pct", 50) / 100))}
                for w in weather_raw
            ]
            engine.set_pv_forecast(pv_forecast)
        
        # Preise
        price_forecast = _fetch_price_forecast(hours)
        engine.set_price_forecast(price_forecast)
        
        windows = engine.generate_optimization_windows(hours_ahead=hours)
        
        return jsonify({
            "ok": True,
            "generated_at": datetime.now().isoformat(),
            "windows": [asdict(w) for w in windows],
        })
    
    except Exception as e:
        _LOGGER.error("Optimization windows error: %s", e)
        return jsonify({
            "ok": False,
            "error": str(e),
        }), 500


@energy_forecast_bp.route("/load-shifting/devices", methods=["POST"])
@require_token
def register_shiftable_device():
    """Registriere verschiebbares Gerät.
    
    Body:
    {
        "device_id": "...",
        "device_type": "washer|dryer|dishwasher|ev_charger|heat_pump|battery",
        "name": "...",
        "power_kw": 2.0,
        "energy_kwh": 1.5,
        "duration_hours": 1.5,
        "flexibility_hours": 8,
        "priority": 3,
        "min_start_hour": 0,
        "max_start_hour": 23,
        "must_complete_by": "2024-01-01T18:00:00"
    }
    
    Returns:
    {
        "ok": true,
        "device": {...},
        "message": "Gerät registriert"
    }
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                "ok": False,
                "error": "Keine Daten",
            }), 400
        
        required = ["device_id", "device_type", "name"]
        for field in required:
            if field not in data:
                return jsonify({
                    "ok": False,
                    "error": f"Fehlendes Feld: {field}",
                }), 400
        
        # Gerät erstellen
        device = ShiftableDevice(
            device_id=data["device_id"],
            device_type=data["device_type"],
            name=data["name"],
            power_kw=data.get("power_kw", 2.0),
            energy_kwh=data.get("energy_kwh", 1.5),
            duration_hours=data.get("duration_hours", 1.5),
            flexibility_hours=data.get("flexibility_hours", 8),
            priority=data.get("priority", 3),
            min_start_hour=data.get("min_start_hour", 0),
            max_start_hour=data.get("max_start_hour", 23),
            must_complete_by=data.get("must_complete_by"),
            current_state=data.get("current_state", "idle"),
            cost_per_kwh=data.get("cost_per_kwh", 30.0),
        )
        
        # In Session speichern (hier: temporär)
        # In Produktion: Database oder Energy Service
        _LOGGER.info("Registered shiftable device: %s (%s)", device.device_id, device.device_type)
        
        return jsonify({
            "ok": True,
            "device": asdict(device),
            "message": f"Gerät '{device.name}' registriert",
        })
    
    except Exception as e:
        _LOGGER.error("Register device error: %s", e)
        return jsonify({
            "ok": False,
            "error": str(e),
        }), 500


@energy_forecast_bp.route("/summary", methods=["GET"])
@require_token
def get_energy_summary():
    """Hole kompakte Energie-Übersicht für Dashboard.
    
    Returns:
    {
        "ok": true,
        "current": {
            "consumption_kw": ...,
            "pv_kw": ...,
            "balance_kw": ...,
            "price_ct_kwh": ...
        },
        "today": {
            "consumption_kwh": ...,
            "pv_kwh": ...,
            "cost_eur": ...,
            "self_sufficiency_pct": ...
        },
        "next_24h": {
            "best_consumption_hour": "...",
            "best_pv_hour": "...",
            "recommendation": "..."
        }
    }
    """
    try:
        # Aktuelle Daten (vereinfacht)
        now = datetime.now()
        
        # Wetter für aktuelle PV-Schätzung
        weather_service = _get_weather_service()
        cloud_cover = 50
        if weather_service:
            try:
                current_weather = weather_service.get_current()
                cloud_cover = current_weather.get("cloud_cover_pct", 50) if current_weather else 50
            except Exception:
                pass
        
        # PV-Schätzung
        pv_kw = max(0, 5.0 * (1 - cloud_cover / 100))
        if now.hour < 6 or now.hour > 20:
            pv_kw = 0
        
        # Verbrauch (Basis-Profil)
        hour = now.hour
        if 18 <= hour <= 21:
            consumption_kw = 1.2
        elif 6 <= hour <= 9:
            consumption_kw = 0.7
        else:
            consumption_kw = 0.4
        
        balance = pv_kw - consumption_kw
        
        # Preis
        price = 30.0
        price_forecast = _fetch_price_forecast(1)
        if price_forecast:
            price = price_forecast[0].get("price_ct_kwh", 30.0)
        
        return jsonify({
            "ok": True,
            "generated_at": now.isoformat(),
            "current": {
                "consumption_kw": round(consumption_kw, 2),
                "pv_kw": round(pv_kw, 2),
                "balance_kw": round(balance, 2),
                "price_ct_kwh": round(price, 2),
                "grid_import": round(max(0, consumption_kw - pv_kw), 2),
                "pv_export": round(max(0, pv_kw - consumption_kw), 2),
            },
            "today": {
                "consumption_kwh": round(consumption_kw * 24 * 0.6, 1),  # Schätzung
                "pv_kwh": round(pv_kw * 6, 1),  # Schätzung
                "cost_eur": round(consumption_kw * 24 * 0.6 * price / 100, 2),
                "self_sufficiency_pct": round(min(100, pv_kw / max(0.1, consumption_kw) * 100), 1),
            },
            "next_24h": {
                "best_consumption_hour": "14:00" if 14 > hour else "14:00 (morgen)",
                "best_pv_hour": "13:00" if 13 > hour else "13:00 (morgen)",
                "recommendation": "Waschmaschine heute Nachmittag starten — PV-Spitze!",
            },
        })
    
    except Exception as e:
        _LOGGER.error("Energy summary error: %s", e)
        return jsonify({
            "ok": False,
            "error": str(e),
        }), 500
